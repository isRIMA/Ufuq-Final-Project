import React, { useEffect, useState } from "react"; // Import React
import { useLocation, useNavigate } from "react-router-dom"; // Import routing and location state
import "./PerformanceRecord.css"; // Import shared CSS file 

export default function SuggestionsPage() { // Define and export the SuggestionsPage functional component
  const location = useLocation(); // Get the current location object to access passed state
  const navigate = useNavigate(); // Get the navigate function for programmatic navigation

  // Receive child data from the state sent via the sidebar
  const child = location.state?.child; // Extract child object from navigation state (optional chaining for safety)

  const [recs, setRecs] = useState([]); // State to store recommendations fetched from the database
  const [dominantStyle, setDominantStyle] = useState(""); // State to store the dominant learning style
  const [loading, setLoading] = useState(true); // State to track loading status, initially true

  useEffect(() => { // Run side effect when component mounts or when child changes
    if (!child?.id) return; // Exit early if child or child ID is not available

    // 1. Fetch the last test result for the child to determine the current dominant style
    fetch(`https://ufuqedu.org/api/get-last-result/${child.id}`) // Make GET request to fetch child's last test result by ID
      .then((res) => res.json()) // Parse the response body as JSON
      .then((data) => { // Handle the parsed data from the last result API
        if (data.result && data.result.dominant) { // Check if result exists and has a dominant style
          const style = data.result.dominant; // Extract the dominant learning style value
          setDominantStyle(style); // Update dominantStyle state with the fetched style
          
          // 2. After knowing the style, fetch the appropriate recommendations for it
          return fetch(`https://ufuqedu.org/api/get-recommendations/${style}`); // Make GET request to fetch recommendations based on dominant style
        } else { // If no valid result is found in the response
          throw new Error("No test results found"); // Throw an error to trigger the catch block
        }
      })
      .then((res) => res.json()) // Parse the recommendations response as JSON
      .then((data) => { // Handle the parsed recommendations data
        setRecs(data || []); // Update recs state with fetched data, fallback to empty array
        setLoading(false); // Set loading to false once data is successfully fetched
      })
      .catch((err) => { // Handle any errors from either fetch call
        console.error("Error:", err); // Log the error to the console for debugging
        setLoading(false); // Set loading to false even if there was an error
      });
  }, [child]); // Re-run effect whenever the child object changes

  if (!child) return <p className="performance-loading">❌ لم يتم العثور على بيانات الطفل</p>; // Render error message if child data is missing
  if (loading) return <p className="performance-loading">جاري تحليل النمط وجلب التوصيات...</p>; // Render loading message while data is being fetched

  return ( // Return the JSX for the SuggestionsPage component
    <div className="performance-page-container" dir="rtl"> {/* Main wrapper div with RTL text direction */}
      
      {/* MAIN CONTAINER */}
      <div className="performance-main-container"> {/* Inner main container s */}
        
        {/* HEADER CARD */}
        <div className="performance-header-card"> {/* Header section card */}
          {/* Back button */}
          <span
            className="material-symbols-outlined performance-back-btn" // Apply material icon and back button styles
            onClick={() => navigate(-1)} // Navigate to the previous page 
          >
            arrow_back {/* Material icon name for back arrow */}
          </span>

          <h1 className="performance-page-title">المصادر المقترحة</h1> {/* Page title: "Suggested Resources" */}

          {/* Child info  */}
          <div className="performance-child-card"> {/* Child information card container */}
            <div className="performance-child-img-wrapper"> {/* Wrapper for child's profile image */}
              <img
                src={child.image || "https://i.ibb.co/3F0xXJ3/kid-avatar-1.png"} // Use child's image or fallback to default avatar
                alt={child.child_name} // Set alt text to child's name for accessibility
              />
            </div>

            <div> {/* Container for child name and label text */}
              <p className="performance-child-label">مصادر تعليمية لـ:</p> {/* Label: "Educational resources for:" */}
              <p className="performance-child-name">{child.child_name}</p> {/* Display the child's name dynamically */}
            </div>
          </div>
        </div>

        {/* RECORDS CONTAINER */}
        <div className="performance-records-container"> {/* Container for the list of recommendations */}
          
          {/* Display the current dominant style prominently */}
          <p className="performance-dominant" style={{ textAlign: "center", marginBottom: "25px" }}> {/* Centered paragraph with bottom margin */}
            بناءً على نمط الانتباه الحالي:{" "} {/* Text: "Based on the current attention style:" with trailing space */}
            <span style={{ color: "#6c5ce7", fontWeight: "bold" }}> {/* Styled span for the style name in purple and bold */}
              {dominantStyle.toLowerCase() === "visual" ? "بصري" :  // If style is "visual", display Arabic "بصري"
               dominantStyle.toLowerCase() === "audio" || dominantStyle.toLowerCase() === "auditory" ? "سمعي" : "مختلط"} {/* If "audio" or "auditory" display "سمعي", otherwise display "مختلط" (mixed) */}
            </span>
          </p>

          {recs.length === 0 ? ( // Check if recommendations array is empty
            <p className="performance-no-records">لا توجد مصادر مقترحة متاحة لهذا النمط حالياً</p> // Show message if no recommendations are available
          ) : ( // Otherwise render the list of recommendations
            recs.map((item, index) => ( // Map over each recommendation item to render a card
              <div 
                className="performance-record-card" // Apply shared record card styles
                key={index} // Use index as key for each mapped element
                style={{ borderRight: "5px solid #6c5ce7", padding: "20px" }} // Add purple right border and padding inline
              >
                <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "15px" }}> {/* Flex row for icon and label with spacing */}
                  <span className="material-symbols-outlined" style={{ color: "#fdcb6e" }}> {/* Material icon styled in yellow */}
                    auto_awesome {/* Material icon name for sparkle/star effect */}
                  </span>
                  <p className="performance-label" style={{ margin: 0 }}>مصدر تعليمي مخصص</p> {/* Label: "Personalized educational resource" with no margin */}
                </div>

                {/* Resource name as an interactive link that opens in a new tab */}
                <a 
                  href={item.Link.startsWith('http') ? item.Link : `https://${item.Link}`}  // Use link as-is if it starts with http, otherwise prepend https://
                  target="_blank" // Open the link in a new browser tab
                  rel="noopener noreferrer" // Security attribute to prevent tab hijacking
                  style={{ // Inline styles for the anchor element
                    fontSize: "18px", // Set font size for the link text
                    color: "#6c5ce7", // Purple color for the link
                    fontWeight: "bold", // Bold font weight
                    textDecoration: "none", // Remove default underline
                    display: "flex", // Use flexbox layout
                    alignItems: "center", // Vertically center content
                    justifyContent: "space-between", // Space between name and icon
                    background: "#f8f9ff", // Light background color
                    padding: "15px", // Padding inside the link box
                    borderRadius: "12px", // Rounded corners
                    border: "1px solid #eee" // Light grey border
                  }}
                >
                  {item.Source_name} {/* Display the name of the educational resource */}
                  <span className="material-symbols-outlined" style={{ fontSize: "20px" }}> {/* External link icon with specified size */}
                    open_in_new {/* Material icon name for "open in new tab" */}
                  </span>
                </a>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}