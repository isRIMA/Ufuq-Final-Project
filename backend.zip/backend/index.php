<?php
// ================== 1. إعدادات الـ CORS والرؤوس ==================
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, GET, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// التعامل مع طلبات Preflight (تلقائي من المتصفح)
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ================== 2. الاتصال بقاعدة البيانات ==================
$host = "127.0.0.1";
$db_name = "u626940993_Ufuq";
$username = "u626940993_ufuq";
$password = "Ufuq2026$#";

try {
    $conn = new PDO("mysql:host=$host;dbname=$db_name;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(["msg" => "Database connection error", "error" => $e->getMessage()]);
    exit();
}

// دالة لجلب البيانات من الـ Request Body (JSON)
function get_input() {
    return json_decode(file_get_contents("php://input"), true);
}

// ================== 3. استخراج المسار (Routing) ==================
// تعديل ذكي ليتناسب مع وجود الملف داخل مجلد api أو المجلد الرئيسي
$request_uri = $_SERVER['REQUEST_URI'];
$base_path = str_replace('/index.php', '', $_SERVER['SCRIPT_NAME']);
$path = str_replace($base_path, '', $request_uri);

// إزالة أي Query String (مثل ?id=1)
$path = explode('?', $path)[0];
if (empty($path) || $path == '') $path = '/';

$method = $_SERVER['REQUEST_METHOD'];

// ================== 3. معالجة المسارات (Routes) ==================

// --- تسجيل الدخول (Login) ---
if ($path == '/login' && $method == 'POST') {
    $data = get_input();
    $email = $data['email'] ?? '';
    $pass = $data['password'] ?? '';

    if (empty($email) || empty($pass)) {
        http_response_code(400); echo json_encode(["msg" => "All fields are required."]); exit();
    }

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($pass, $user['password'])) {
        unset($user['password']); // حذف الباسورد من النتيجة للأمان
        echo json_encode(["msg" => "Login successful!", "userData" => $user]);
    } else {
        http_response_code(400); echo json_encode(["msg" => $user ? "Incorrect password." : "Email not found."]);
    }
}

// --- إنشاء حساب (Create Account) ---
elseif ($path == '/create-account' && $method == 'POST') {
    $data = get_input();
    if (empty($data['firstName']) || empty($data['lastName']) || empty($data['email']) || empty($data['password'])) {
        http_response_code(400); echo json_encode(["msg" => "All fields are required."]); exit();
    }
    try {
        $hashed = password_hash($data['password'], PASSWORD_BCRYPT);
        $stmt = $conn->prepare("INSERT INTO users (firstName, lastName, email, password) VALUES (?, ?, ?, ?)");
        $stmt->execute([$data['firstName'], $data['lastName'], $data['email'], $hashed]);
        echo json_encode([
            "msg" => "Account created successfully!", 
            "userData" => ["id" => $conn->lastInsertId(), "firstName" => $data['firstName'], "lastName" => $data['lastName'], "email" => $data['email']]
        ]);
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) { http_response_code(400); echo json_encode(["msg" => "Email already registered."]); }
        else { http_response_code(500); echo json_encode(["msg" => "Database error", "error" => $e->getMessage()]); }
    }
}

// --- 1. جلب بيانات مستخدم محدد (GET /users/:id) ---
elseif (preg_match('/^\/users\/(\d+)$/', $path, $matches) && $method == 'GET') {
    $userId = $matches[1];
    $stmt = $conn->prepare("SELECT id, firstName, lastName, email FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        echo json_encode($user);
    } else {
        http_response_code(404);
        echo json_encode(["msg" => "المستخدم غير موجود"]);
    }
}

// --- 2. تحديث بيانات المستخدم (Update user data - PUT /users/:id) ---
elseif (preg_match('/^\/users\/(\d+)$/', $path, $matches) && $method == 'PUT') {
    $userId = $matches[1];
    $data = get_input();
    
    if (empty($data['firstName']) || empty($data['lastName']) || empty($data['email'])) {
        http_response_code(400); 
        echo json_encode(["msg" => "جميع الحقول مطلوبة"]); 
        exit();
    }

    try {
        $stmt = $conn->prepare("UPDATE users SET firstName = ?, lastName = ?, email = ? WHERE id = ?");
        $stmt->execute([$data['firstName'], $data['lastName'], $data['email'], $userId]);
        
        if ($stmt->rowCount() == 0) { 
            // ملاحظة: rowCount قد تكون 0 إذا لم يتم تغيير أي بيانات فعلياً حتى لو المستخدم موجود
            echo json_encode(["msg" => "تم تحديث البيانات أو لم يطرأ تغيير"]); 
        } else { 
            echo json_encode(["msg" => "تم تحديث البيانات بنجاح"]); 
        }
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) { 
            http_response_code(400); 
            echo json_encode(["msg" => "الإيميل مستخدم مسبقًا"]); 
        } else { 
            http_response_code(500); 
            echo json_encode(["msg" => "Database error", "error" => $e->getMessage()]); 
        }
    }
}

// --- إضافة طفل (Add a child) ---
elseif ($path == '/add-child' && $method == 'POST') {
    $data = get_input();
    if (empty($data['parentId']) || empty($data['child_name']) || empty($data['age'])) {
        http_response_code(400); echo json_encode(["msg" => "All fields required."]); exit();
    }
    $stmt = $conn->prepare("INSERT INTO children (parent_id, child_name, age, image) VALUES (?, ?, ?, ?)");
    $stmt->execute([$data['parentId'], $data['child_name'], $data['age'], $data['image'] ?? null]);
    echo json_encode(["msg" => "Child added successfully", "child" => ["id" => $conn->lastInsertId(), "child_name" => $data['child_name'], "age" => $data['age'], "image" => $data['image'] ?? null]]);
}

// --- تحديث بيانات الطفل (Update child) ---
elseif ($path == '/update-child' && $method == 'PUT') {
    $data = get_input();
    if (empty($data['childId']) || empty($data['child_name']) || empty($data['age'])) {
        http_response_code(400); echo json_encode(["msg" => "All fields required."]); exit();
    }
    $stmt = $conn->prepare("UPDATE children SET child_name = ?, age = ?, image = ? WHERE id = ?");
    $stmt->execute([$data['child_name'], $data['age'], $data['image'] ?? null, $data['childId']]);
    echo json_encode(["msg" => "Child updated successfully"]);
}

// --- جلب أطفال والد معين (Retrieve user's children) ---
elseif (preg_match('/^\/children\/(\d+)$/', $path, $matches) && $method == 'GET') {
    $stmt = $conn->prepare("SELECT * FROM children WHERE parent_id = ?");
    $stmt->execute([$matches[1]]);
    echo json_encode(["children" => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
}

// --- جلب بيانات طفل واحد (Retrieve one child) ---
elseif (preg_match('/^\/get-child\/(\d+)$/', $path, $matches) && $method == 'GET') {
    $stmt = $conn->prepare("SELECT * FROM children WHERE id = ?");
    $stmt->execute([$matches[1]]);
    $child = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$child) { http_response_code(404); echo json_encode(["msg" => "Child not found"]); }
    else { echo json_encode($child); }
}

// --- حفظ نتيجة اختبار (Save test result) ---

elseif ($path == '/save-test-result' && $method == 'POST') {

    $data = get_input();

    // 1. حفظ البيانات أولاً
    $sql = "INSERT INTO test_results 
    (child_id, visual, audio, dominant, total_correct, total_wrong, duration_seconds, total_skipped, total_mic_clicks, total_drag_cancels) 
    VALUES (?, ?, ?, 'processing', ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    $stmt->execute([
        $data['child_id'],
        $data['visual'],
        $data['audio'],
        $data['total_correct'],
        $data['total_wrong'],
        $data['duration_seconds'],
        $data['total_skipped'] ?? 0,
        $data['mic_clicks'] ?? 0,
        $data['drag_cancels'] ?? 0
    ]);

    $lastId = $conn->lastInsertId();

    // 2. إرسال البيانات إلى Flask API
    $url = "https://ufuq-api.onrender.com/predict";

    $options = [
        "http" => [
            "header"  => "Content-Type: application/json",
            "method"  => "POST",
            "content" => json_encode($data),
            "timeout" => 15
        ]
    ];

    $context = stream_context_create($options);
    $response = file_get_contents($url, false, $context);

    // 3. استخراج prediction
    if ($response !== FALSE) {
        $result = json_decode($response, true);
        $prediction = $result['prediction'] ?? 'unknown';
    } else {
        $prediction = 'error';
    }

    // 4. تحديث النتيجة
    $update = $conn->prepare("UPDATE test_results SET dominant = ? WHERE id = ?");
    $update->execute([$prediction, $lastId]);

    // 5. الرد
    echo json_encode([
        "success" => true,
        "prediction" => $prediction,
        "id" => $lastId
    ]);
}

// --- جلب آخر نتيجة (Retrieve latest result) ---
elseif (preg_match('/^\/get-last-result\/(\d+)$/', $path, $matches) && $method == 'GET') {
    $stmt = $conn->prepare("SELECT * FROM test_results WHERE child_id = ? ORDER BY id DESC LIMIT 1");
    $stmt->execute([$matches[1]]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode($row ? ["result" => $row] : ["message" => "No results found", "result" => null]);
}

// --- حفظ تفاصيل اللعبة (Save details of a single game) ---
elseif ($path == '/save-game-detail' && $method == 'POST') {
    $data = get_input();
    if (empty($data['test_result_id'])) { http_response_code(400); echo json_encode(["msg" => "Missing test_result_id."]); exit(); }
    $sql = "INSERT INTO game_details (test_result_id, game_name, correct_answers, wrong_answers, skipped_answers, duration_seconds, mic_clicks, drag_cancels) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        $data['test_result_id'], $data['game_name'], $data['correct_answers'], $data['wrong_answers'],
        $data['skipped_answers'], $data['duration_seconds'], $data['mic_clicks'] ?? 0, $data['drag_cancels'] ?? 0
    ]);
    echo json_encode(["msg" => "Game detail saved successfully", "id" => $conn->lastInsertId()]);
}

// --- جلب جميع نتائج الطفل (Performance records) ---
elseif (preg_match('/^\/performance-records\/(\d+)$/', $path, $matches) && $method == 'GET') {
    $stmt = $conn->prepare("SELECT id, visual, audio, dominant, total_correct, total_wrong, duration_seconds, created_at FROM test_results WHERE child_id = ? ORDER BY id DESC");
    $stmt->execute([$matches[1]]);
    echo json_encode(["records" => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
}

// --- حذف طفل (Delete child) ---
elseif (preg_match('/^\/children\/delete\/(\d+)$/', $path, $matches) && $method == 'DELETE') {
    $stmt = $conn->prepare("DELETE FROM children WHERE id = ?");
    $stmt->execute([$matches[1]]);
    if ($stmt->rowCount() == 0) { http_response_code(404); echo json_encode(["msg" => "Child not found"]); }
    else { echo json_encode(["msg" => "Child deleted successfully"]); }
}
// --- فحص وجود الإيميل (Check email) ---
elseif ($path == '/check-email' && $method == 'POST') {
    $data = get_input();
    $email = $data['email'] ?? '';

    if (empty($email)) {
        http_response_code(400); echo json_encode(["msg" => "الرجاء إدخال البريد الإلكتروني"]); exit;
    }

    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);

    if ($stmt->rowCount() == 0) {
        http_response_code(404); echo json_encode(["msg" => "الإيميل غير مسجّل لدينا"]);
    } else {
        echo json_encode(["success" => true, "msg" => "الإيميل موجود"]);
    }
}

// --- إعادة تعيين كلمة المرور (Reset password) ---
elseif ($path == '/reset-password' && $method == 'POST') {
    $data = get_input(); 
    $email = $data['email'] ?? '';
    $newPass = $data['newPassword'] ?? ''; 

    if (empty($email) || empty($newPass)) {
        http_response_code(400); echo json_encode(["msg" => "الحقول مطلوبة"]); exit();
    }

    $hashed = password_hash($newPass, PASSWORD_BCRYPT);
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
    $result = $stmt->execute([$hashed, $email]);

    if ($result) {
        echo json_encode(["success" => true, "msg" => "تم إعادة تعيين كلمة المرور بنجاح"]);
    } else {
        http_response_code(500); echo json_encode(["msg" => "Error updating password"]);
    }
}

// --- جلب التوصيات بناءً على النمط (Get Recommendations) ---
elseif (preg_match('/^\/get-recommendations\/([a-zA-Z]+)$/', $path, $matches) && $method == 'GET') {
    $style = $matches[1]; // القيمة القادمة من React (visual, audio, mixed)

    // تحويل القيمة لتطابق القيم الموجودة في عمود Attention_type في قاعدة البيانات
    $dbStyle = "";
    if ($style === 'audio') {
        $dbStyle = 'Auditory';
    } elseif ($style === 'visual') {
        $dbStyle = 'Visual';
    } else {
        $dbStyle = 'Mix';
    }

    try {
        // استعلام لجلب اسم المصدر والرابط بناءً على النمط
        $stmt = $conn->prepare("SELECT Source_name, Link FROM recommendation WHERE Attention_type = ?");
        $stmt->execute([$dbStyle]);
        $recommendations = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode($recommendations);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(["msg" => "Database error", "error" => $e->getMessage()]);
    }
}

// --- مسارات الاختبار (Ping & DB Test) ---
elseif ($path == '/ping') { echo json_encode(["status" => "Server is running"]); }
elseif ($path == '/test-db') { 
    $res = $conn->query("SELECT 1 + 1 AS result")->fetch(PDO::FETCH_ASSOC);
    echo json_encode(["result" => $res]); 
}

// مسار 404
else {
    http_response_code(404);
    echo json_encode(["msg" => "Route not found"]);
}